package calculadora;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Label;
import javax.swing.JTextField;

public class Calculadora extends JFrame {
	
	
	private JPanel contentPane;
	private JTextField conta;

	float valorAnterior, valorAtual, resultado;
    int operacao;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculadora frame = new Calculadora();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public Calculadora() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 426, 232);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("1");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				conta.setText(conta.getText()+"1");
			
			}
		});
		btnNewButton.setBounds(10, 58, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("2");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				conta.setText(conta.getText()+"2");
			}
		});
		btnNewButton_1.setBounds(109, 58, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("3");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				conta.setText(conta.getText()+"3");
			}
		});
		btnNewButton_2.setBounds(208, 58, 89, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("+");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				valorAnterior =  Float.parseFloat(conta.getText());
				conta.setText(null);
				operacao=1;
			}
		});
		btnNewButton_3.setBounds(307, 58, 89, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("4");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				conta.setText(conta.getText()+"4");
			}
		});
		btnNewButton_4.setBounds(10, 92, 89, 23);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("5");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				conta.setText(conta.getText()+"5");
			}
		});
		btnNewButton_5.setBounds(109, 92, 89, 23);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("6");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				conta.setText(conta.getText()+"6");
			}
		});
		btnNewButton_6.setBounds(208, 92, 89, 23);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("-");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				valorAnterior =  Float.parseFloat(conta.getText());
				conta.setText(null);
				operacao=2;
			}
		});
		btnNewButton_7.setBounds(307, 92, 89, 23);
		contentPane.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("7");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				conta.setText(conta.getText()+"7");
			}
		});
		btnNewButton_8.setBounds(10, 126, 89, 23);
		contentPane.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("8");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				conta.setText(conta.getText()+"8");
			}
		});
		btnNewButton_9.setBounds(109, 126, 89, 23);
		contentPane.add(btnNewButton_9);
		
		JButton btnNewButton_10 = new JButton("9");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				conta.setText(conta.getText()+"9");
			}
		});
		btnNewButton_10.setBounds(208, 126, 89, 23);
		contentPane.add(btnNewButton_10);
		
		JButton btnNewButton_11 = new JButton("*");
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				valorAnterior =  Float.parseFloat(conta.getText());
				conta.setText(null);
				operacao=3;
			}
		});
		btnNewButton_11.setBounds(307, 126, 89, 23);
		contentPane.add(btnNewButton_11);
		
		JButton btnNewButton_12 = new JButton("0");
		btnNewButton_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				conta.setText(conta.getText()+"0");
			}
		});
		btnNewButton_12.setBounds(10, 160, 89, 23);
		contentPane.add(btnNewButton_12);
		
		
		JButton btnNewButton_15 = new JButton("/");
		btnNewButton_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				valorAnterior =  Float.parseFloat(conta.getText());
				conta.setText(null);
				operacao=4;}
		});
		
	

		
		
		
		btnNewButton_15.setBounds(307, 160, 89, 23);
		contentPane.add(btnNewButton_15);
		
		Label label = new Label("CONTA:");
		label.setBounds(10, 27, 42, 22);
		contentPane.add(label);
		
		conta = new JTextField();
		conta.setBounds(58, 27, 338, 20);
		contentPane.add(conta);
		conta.setColumns(10);
		
		JButton btnNewButton_13 = new JButton("=");
		btnNewButton_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				valorAtual =   Float.parseFloat(conta.getText());
				    if (operacao == 1) { resultado = valorAnterior + valorAtual; }
	                if (operacao == 2) { resultado = valorAnterior - valorAtual; }
	                if (operacao == 3) { resultado = valorAnterior * valorAtual; }
	                if (operacao == 4) { resultado = valorAnterior / valorAtual; }
	                conta.setText( String.valueOf(resultado)   );
		}
		});
		btnNewButton_13.setBounds(208, 160, 89, 23);
		contentPane.add(btnNewButton_13);
		
		JButton btnNewButton_14 = new JButton("C");
		btnNewButton_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				conta.setText("");
				
				
				
				
			}
		});
		btnNewButton_14.setBounds(109, 160, 89, 23);
		contentPane.add(btnNewButton_14);
	}
}
